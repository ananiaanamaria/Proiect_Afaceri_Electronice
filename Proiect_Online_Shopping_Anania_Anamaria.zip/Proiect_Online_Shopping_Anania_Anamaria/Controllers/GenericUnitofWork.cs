﻿using Proiect_Online_Shopping_Anania_Anamaria.Repository;

namespace Proiect_Online_Shopping_Anania_Anamaria.Controllers
{
    public class GenericUnitofWork : GenericUnitOfWork
    {
    }
}